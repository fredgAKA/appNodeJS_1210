const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

app.post('/bienvenue', (req, res) => {
  const name = req.body.name;
  res.send(`Bienvenue, ${name}, tu es bien matinal(e).`);
});

app.listen(port, () => {
  console.log(`Le serveur est en écoute sur le port ${port}`);
});
